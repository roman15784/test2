<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
    <style>
        body {
            background-color: #ccccff;
        }
    </style>
</head>
<body>
	<input type="text" id="number">
        <button id="send">Перевести</button>
        <hr>
        <div id="answer"></div>
        
        <script>
            var http = new XMLHttpRequest();
            var button = document.getElementById('send');
            var answer = document.getElementById('answer');
            var number = document.getElementById('number');
            
            button.onclick = function() {
                if(number.value != "") {
                    translate();
                } else {
                    answer.innerHTML = "Вы не ввели число";
                }
            }
            
            http.onreadystatechange = function() {
                if (http.readyState==4 && http.status==200) {
                    answer.innerHTML = http.responseText;
                }
            }
            
            function translate() {
                http.open("GET","request2.php?number="+number.value, true);
                http.send();
            }
            
        </script>
</body>
</html>